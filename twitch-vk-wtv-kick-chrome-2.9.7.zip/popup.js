'use strict';

(async () => {
  const api = globalThis.browser || globalThis.chrome;
  const RU = /^(ru|uk|be|kk)/i.test(navigator.language || '');
  const list = document.getElementById('list');
  const note = (text) => {
    const p = document.createElement('div');
    p.className = 'note';
    p.textContent = text;
    list.replaceChildren(p);
  };

  let tab;
  try {
    [tab] = await api.tabs.query({ active: true, currentWindow: true });
  } catch {
    tab = null;
  }
  if (!tab || typeof tab.id !== 'number') {
    note(RU ? 'Откройте вкладку Twitch.' : 'Open a Twitch tab.');
    return;
  }

  let items = null;
  try {
    items = await api.tabs.sendMessage(tab.id, { t: 'menu-list' }, { frameId: 0 });
  } catch {
    items = null;
  }
  if (!Array.isArray(items) || !items.length) {
    note(RU ? 'Откройте страницу twitch.tv, чтобы настроить каналы.' : 'Open a twitch.tv page to configure channels.');
    return;
  }

  list.replaceChildren(...items.map((it) => {
    const b = document.createElement('button');
    b.type = 'button';
    b.textContent = String(it.name);
    b.addEventListener('click', async () => {
      try { await api.tabs.sendMessage(tab.id, { t: 'menu-run', id: it.id }, { frameId: 0 }); } catch { }
      window.close();
    });
    return b;
  }));
})();
