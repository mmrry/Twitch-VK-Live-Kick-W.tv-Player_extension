(() => {
  'use strict';
  const api = globalThis.browser || globalThis.chrome;
  if (typeof globalThis.Hls !== 'undefined' && window.Hls !== globalThis.Hls) {
    try { window.Hls = globalThis.Hls; } catch { }
  }
  let cache = {};
  const menu = new Map();
  let menuSeq = 0;

  const fromB64 = (s) => {
    const bin = atob(s || '');
    const out = new Uint8Array(bin.length);
    for (let i = 0; i < bin.length; i++) out[i] = bin.charCodeAt(i);
    return out.buffer;
  };

  globalThis.GM_getValue = (k, d) => (Object.prototype.hasOwnProperty.call(cache, k) ? cache[k] : d);

  globalThis.GM_setValue = (k, v) => {
    cache[k] = v;
    try { Promise.resolve(api.storage.local.set({ [k]: v })).catch(() => {}); } catch { }
  };

  globalThis.GM_registerMenuCommand = (name, fn) => {
    menuSeq += 1;
    menu.set(menuSeq, { name: String(name), fn });
    return menuSeq;
  };

  globalThis.GM_unregisterMenuCommand = (id) => { menu.delete(id); };

  globalThis.GM_getTab = (cb) => {
    Promise.resolve(api.runtime.sendMessage({ t: 'tab-get' }))
      .then((v) => cb(v && typeof v === 'object' ? v : {}), () => cb({}));
  };

  globalThis.GM_saveTab = (v) => {
    try { Promise.resolve(api.runtime.sendMessage({ t: 'tab-save', v })).catch(() => {}); } catch { }
  };

  globalThis.GM_xmlhttpRequest = (o) => {
    let done = false;
    let port = null;
    const finish = () => {
      done = true;
      try { port.disconnect(); } catch { }
    };
    try {
      port = api.runtime.connect({ name: 'tvk-xhr' });
    } catch (e) {
      setTimeout(() => { if (o.onerror) o.onerror({ error: String(e) }); }, 0);
      return { abort() { } };
    }
    port.onMessage.addListener((m) => {
      if (done || !m) return;
      if (m.t === 'progress') {
        if (o.onprogress) o.onprogress({ loaded: m.loaded, total: m.total, lengthComputable: m.total > 0 });
        return;
      }
      if (m.t === 'load') {
        finish();
        const buf = fromB64(m.body);
        const binary = o.responseType === 'arraybuffer';
        if (o.onload) {
          o.onload({
            status: m.status,
            statusText: m.statusText,
            finalUrl: m.finalUrl,
            response: binary ? buf : new TextDecoder().decode(buf),
            responseText: binary ? undefined : new TextDecoder().decode(buf),
          });
        }
        return;
      }
      if (m.t === 'timeout') {
        finish();
        if (o.ontimeout) o.ontimeout({});
        return;
      }
      if (m.t === 'error') {
        finish();
        if (o.onerror) o.onerror({ error: m.error });
      }
    });
    port.onDisconnect.addListener(() => {
      if (done) return;
      done = true;
      if (o.onerror) o.onerror({ error: 'disconnected' });
    });
    port.postMessage({
      t: 'req',
      url: String(o.url),
      method: o.method || 'GET',
      headers: o.headers && typeof o.headers === 'object' ? o.headers : {},
      anonymous: o.anonymous === true,
      redirect: o.redirect === 'error' ? 'error' : 'follow',
      timeout: Number(o.timeout) || 0,
    });
    return {
      abort() {
        if (done) return;
        done = true;
        try { port.postMessage({ t: 'abort' }); port.disconnect(); } catch { }
        if (o.onabort) o.onabort({});
      },
    };
  };

  api.runtime.onMessage.addListener((m, sender, send) => {
    if (window.top !== window.self || !m) return undefined;
    if (m.t === 'menu-list') {
      send([...menu].map(([id, x]) => ({ id, name: x.name })));
      return undefined;
    }
    if (m.t === 'menu-run' && menu.has(m.id)) {
      const item = menu.get(m.id);
      setTimeout(() => item.fn(), 0);
      send(true);
    }
    return undefined;
  });

  globalThis.__tvkBoot = (main) => {
    Promise.resolve(api.storage.local.get(null))
      .then((all) => { cache = all && typeof all === 'object' ? all : {}; }, () => { })
      .finally(main);
  };
})();

__tvkBoot(() => {
(() => {
  'use strict';

  if (location.hostname === 'live.vkvideo.ru') {
    if (window.top !== window.self && location.pathname.startsWith('/app/embed/')) vkEmbedTweaks();
    return;
  }
  if (window.top !== window.self) return;

  function vkEmbedTweaks() {
    const style = document.createElement('style');
    style.textContent = [
      '[class*="VideoPlayer_streamBtn_"]{display:none!important}',
      'html,body{overflow:hidden!important}',
      '[class*="AppContent_contentWrapper_"]{overflow:hidden!important}',
      '*{scrollbar-width:none!important;-ms-overflow-style:none!important}',
      '*::-webkit-scrollbar{display:none!important;width:0!important;height:0!important}',
    ].join('\n');
    (document.head || document.documentElement).append(style);

    const MAX_SCAN_NODES = 5000;
    const findVideo = (root, depth = 0, budget = { left: MAX_SCAN_NODES }) => {
      const v = root.querySelector('video');
      if (v || depth > 4) return v;
      const walker = document.createTreeWalker(root, NodeFilter.SHOW_ELEMENT);
      for (let el = walker.nextNode(); el; el = walker.nextNode()) {
        if (--budget.left <= 0) return null;
        if (el.shadowRoot) { const r = findVideo(el.shadowRoot, depth + 1, budget); if (r) return r; }
      }
      return null;
    };
    let tries = 0;
    let found = null;
    const timer = setInterval(() => {
      tries += 1;
      const v = found && found.isConnected ? found : (found = findVideo(document));
      if (v && !v.paused) { clearInterval(timer); return; }
      if (v && v.readyState >= 2 && tries >= 3) {
        v.play().catch(() => { v.muted = true; v.play().catch(() => {}); });
      }
      if (tries >= 15) clearInterval(timer);
    }, 1000);

    let last = 0;
    const ping = () => {
      const now = Date.now();
      if (now - last < 200) return;
      last = now;
      try { window.parent.postMessage({ tvk: 'activity' }, 'https://www.twitch.tv'); } catch { }
    };
    for (const ev of ['mousemove', 'pointerdown', 'wheel']) document.addEventListener(ev, ping, { passive: true, capture: true });
  }

  const DEFAULT_MAP = { fasoollka: { vk: 'fasolka', wtv: 'fasolka', kick: 'fasollka' } };
  const DEFAULT_VK_MODE = 'embed';
  const DEFAULT_VOLUME = { wtv: 0.05, kick: 0.05, vk: 0.5 };
  const POLL_MS = 60_000;
  const POLL_ERR_MS = 30_000;
  const TICK_MS = 1_000;
  const API_TIMEOUT_MS = 10_000;

  const MAX_API_BYTES = 2 * 1024 * 1024;
  const MAX_PLAYLIST_BYTES = 2 * 1024 * 1024;
  const MAX_SEGMENT_BYTES = 64 * 1024 * 1024;
  const MAX_INFLIGHT_BYTES = 128 * 1024 * 1024;
  const WTV_ID_TTL_MS = 6 * 60 * 60 * 1000;
  const MAX_JSON_NODES = 20_000;
  const MAX_URL_CANDIDATES = 64;

  function isAllowedUrl(raw, hosts) {
    let u;
    try { u = new URL(raw); } catch { return false; }
    if (u.protocol !== 'https:' || u.port !== '' || u.username || u.password) return false;
    const host = u.hostname.toLowerCase();
    if (/^[\d.]+$/.test(host) || host.includes(':') || host.startsWith('[')) return false;
    return hosts.some((d) => host === d || host.endsWith(`.${d}`));
  }

  const debug = { on: GM_getValue('debug', false) === true, menuIds: [] };
  const DEBUG_HOTKEY = (e) => e.altKey && e.shiftKey && !e.ctrlKey && !e.metaKey && e.code === 'KeyD';
  const redact = (s) => String(s)
    .replace(/\?[^\s"']*/g, '?***')
    .replace(/\/sig\/[^/]+/g, '/sig/***')
    .replace(/\/srcIp\/[^/]+/g, '/srcIp/***')
    .replace(/\/[A-Za-z0-9_-]{40,}/g, '/***');
  const LOG = (...a) => { if (debug.on) console.debug('[TwitchVK]', ...a.map((x) => (typeof x === 'string' ? redact(x) : x))); };

  const RU = /^(ru|uk|be|kk)/i.test(navigator.language || '');
  const T = RU ? {
    live: 'В ЭФИРЕ', offline: 'офлайн', checking: 'проверка…', error: 'ошибка API',
    show: 'Показать', hide: 'Twitch', reload: 'Обновить', auto: 'Авто', channel: 'канал',
    mode: 'Сменить плеер VK (Embed / HLS)', loading: 'Загрузка…',
    play: 'Пауза / воспроизведение', mute: 'Звук', full: 'Во весь экран', toLive: 'К прямому эфиру',
    menuMap: '⚙ Каналы Twitch → VK / W.tv / Kick', menuMode: '⇄ Плеер VK: Embed / HLS', menuDebug: '🐞 Debug: каналы в этом плеере',
    menuReset: '🐞 Debug: сбросить каналы', menuDebugOff: '🐞 Debug: выключить (Alt+Shift+D)',
    promptMap: 'Формат: twitch=vk:канал,wtv:канал,kick:канал ; через «;» для нескольких Twitch-каналов',
    promptDebug: 'Каналы для этого Twitch-плеера, формат vk:канал,wtv:канал,kick:канал (пусто — сброс):',
    notChannel: 'Откройте страницу канала Twitch', noStream: 'Стрим не найден (офлайн?)',
    streamErr: 'Ошибка потока, переподключение…', badChannel: 'Недопустимое имя канала',
    noHls: 'Браузер не поддерживает HLS через MSE', clickUnmute: '🔇 Кликните, чтобы включить звук', watch: 'Смотреть здесь',
  } : {
    live: 'LIVE', offline: 'offline', checking: 'checking…', error: 'API error',
    show: 'Show', hide: 'Twitch', reload: 'Reload', auto: 'Auto', channel: 'channel',
    mode: 'Switch VK player (Embed / HLS)', loading: 'Loading…',
    play: 'Play / pause', mute: 'Mute', full: 'Fullscreen', toLive: 'Jump to live',
    menuMap: '⚙ Twitch → VK / W.tv / Kick channels', menuMode: '⇄ VK player: Embed / HLS', menuDebug: '🐞 Debug: channels in this player',
    menuReset: '🐞 Debug: reset channels', menuDebugOff: '🐞 Debug: turn off (Alt+Shift+D)',
    promptMap: 'Format: twitch=vk:channel,wtv:channel,kick:channel ; separate Twitch channels with «;»',
    promptDebug: 'Channels for this Twitch player, format vk:channel,wtv:channel,kick:channel (empty to reset):',
    notChannel: 'Open a Twitch channel page', noStream: 'Stream not found (offline?)',
    streamErr: 'Stream error, reconnecting…', badChannel: 'Invalid channel name',
    noHls: 'This browser does not support HLS via MSE', clickUnmute: '🔇 Click to unmute', watch: 'Watch here',
  };

  const SERVICES = {
    vk: {
      id: 'vk', name: 'VK', cls: 'vk',
      cdnHosts: ['okcdn.ru', 'mycdn.me', 'vkuser.net'],
      embedUrl: (ch) => `https://live.vkvideo.ru/app/embed/${encodeURIComponent(ch)}?autoplay=true`,
    },
    wtv: {
      id: 'wtv', name: 'W.tv', cls: 'wtv',
      cdnHosts: ['live-video.net'],
      embedUrl: null,
    },
    kick: {
      id: 'kick', name: 'Kick', cls: 'kick',
      cdnHosts: ['live-video.net'],
      embedUrl: null,
    },
  };
  const ORDER = ['vk', 'wtv', 'kick'];

  const CHANNEL_RE = /^[a-z0-9_.-]{1,64}$/;
  const FORBIDDEN_KEYS = new Set(['__proto__', 'constructor', 'prototype', 'hasownproperty', 'tostring', 'valueof']);
  const has = (o, k) => o !== null && typeof o === 'object' && Object.prototype.hasOwnProperty.call(o, k);
  const dict = () => Object.create(null);
  const norm = (s) => {
    const v = String(s || '').trim().toLowerCase().replace(/^@/, '')
      .replace(/^https?:\/\/(www\.)?(live\.vkvideo\.ru|vkplay\.live|w\.tv|kick\.com|twitch\.tv)\//, '')
      .replace(/^app\/embed\//, '')
      .replace(/[/?#].*$/, '');
    return CHANNEL_RE.test(v) && !FORBIDDEN_KEYS.has(v) ? v : '';
  };
  const isPlainObj = (o) => o !== null && typeof o === 'object' && !Array.isArray(o);

  function cleanSvcMap(v) {
    const out = dict();
    if (typeof v === 'string') {
      for (const part of v.split(/[,\s]+/).filter(Boolean)) {
        const m = part.match(/^([a-z.]+):(.+)$/i);
        const svc = m ? m[1].toLowerCase().replace('w.tv', 'wtv') : 'vk';
        const ch = norm(m ? m[2] : part);
        if (has(SERVICES, svc) && ch) out[svc] = ch;
      }
      return out;
    }
    if (!isPlainObj(v)) return out;
    for (const svc of ORDER) if (has(v, svc)) { const ch = norm(v[svc]); if (ch) out[svc] = ch; }
    return out;
  }
  function cleanMap(m) {
    const out = dict();
    if (!isPlainObj(m)) return out;
    for (const k of Object.keys(m)) {
      const tw = k === '*' ? '*' : norm(k);
      const v = cleanSvcMap(m[k]);
      if (tw && Object.keys(v).length) out[tw] = v;
    }
    return out;
  }
  const toPlain = (m) => JSON.parse(JSON.stringify(m));
  const clampNum = (v, min, max, def) => {
    const n = Number(v);
    return Number.isFinite(n) ? Math.min(max, Math.max(min, n)) : def;
  };

  const store = {
    map() {
      let m = GM_getValue('channelMap2', null);
      if (m === null) {
        const legacy = GM_getValue('channelMap', null);
        m = legacy === null ? DEFAULT_MAP : legacy;
      }
      return cleanMap(m);
    },
    setMap(m) { GM_setValue('channelMap2', toPlain(cleanMap(m))); },
    vkMode() { return GM_getValue('mode', DEFAULT_VK_MODE) === 'hls' ? 'hls' : 'embed'; },
    setVkMode(m) { GM_setValue('mode', m === 'hls' ? 'hls' : 'embed'); },
    volumeFor(svc) {
      const def = has(DEFAULT_VOLUME, svc) ? DEFAULT_VOLUME[svc] : 0.5;
      const v = clampNum(GM_getValue(`volume_${svc}`, def), 0, 1, def);
      return v > 0 ? v : def;
    },
    setVolumeFor(svc, v) {
      const n = clampNum(v, 0, 1, 0);
      if (has(SERVICES, svc) && n > 0) GM_setValue(`volume_${svc}`, Math.round(n * 100) / 100);
    },
    quality() { return Math.trunc(clampNum(GM_getValue('quality', -1), -1, 64, -1)); },
    setQuality(q) { GM_setValue('quality', Math.trunc(clampNum(q, -1, 64, -1))); },
  };

  const overrides = (() => {
    let cache = dict();
    const hasTab = typeof GM_getTab === 'function' && typeof GM_saveTab === 'function';
    const ready = new Promise((resolve) => {
      if (!hasTab) { resolve(); return; }
      try {
        GM_getTab((tab) => { cache = cleanMap(isPlainObj(tab) ? tab.tvkOverride2 : null); resolve(); });
      } catch { resolve(); }
    });
    return {
      ready,
      get() { return cleanMap(toPlain(cache)); },
      set(o) {
        cache = cleanMap(o);
        if (!hasTab) return;
        try {
          GM_getTab((tab) => {
            const t = isPlainObj(tab) ? tab : {};
            t.tvkOverride2 = toPlain(cache);
            GM_saveTab(t);
          });
        } catch { }
      },
    };
  })();

  const RESERVED = new Set(['', 'directory', 'videos', 'settings', 'search', 'downloads', 'p', 'subscriptions',
    'inventory', 'wallet', 'drops', 'turbo', 'friends', 'messages', 'moderator', 'popout', 'embed', 'jobs',
    'prime', 'store', 'following', 'login', 'signup', 'u', 'team', 'clips']);

  function currentTwitchChannel() {
    const parts = location.pathname.split('/').filter(Boolean);
    if (parts.length !== 1) return null;
    const c = norm(parts[0]);
    return c && !RESERVED.has(c) ? c : null;
  }

  function resolveChannels(tw) {
    const out = dict();
    if (!tw) return out;
    const o = debug.on ? overrides.get() : dict();
    const m = store.map();
    for (const svc of ORDER) {
      const pick = [o[tw], o['*'], m[tw]].find((x) => x && has(x, svc) && typeof x[svc] === 'string');
      if (pick) out[svc] = pick[svc];
    }
    return out;
  }

  const abortError = () => { const e = new Error('aborted'); e.name = 'AbortError'; return e; };
  const decoder = new TextDecoder();

  function apiRequest(url, { hosts, headers = {} }) {
    let handle = null;
    let settled = false;
    let rejectFn = null;
    let watchdog = null;
    const settle = () => { settled = true; clearTimeout(watchdog); };
    const promise = new Promise((resolve, reject) => {
      rejectFn = reject;
      const fail = (e) => {
        if (settled) return;
        settle();
        try { if (handle) handle.abort(); } catch { }
        reject(e);
      };
      if (!isAllowedUrl(url, hosts)) { fail(new Error('URL not allowed')); return; }
      watchdog = setTimeout(() => fail(new Error('timeout')), API_TIMEOUT_MS);
      handle = GM_xmlhttpRequest({
        method: 'GET', url, timeout: API_TIMEOUT_MS,
        anonymous: false,
        redirect: 'error',
        responseType: 'arraybuffer',
        headers: { Accept: 'application/json, text/plain, */*', ...headers },
        onprogress: (e) => {
          if (e && (e.loaded > MAX_API_BYTES || e.total > MAX_API_BYTES)) fail(new Error('response too large'));
        },
        onload: (r) => {
          if (settled) return;
          if (r.finalUrl && !isAllowedUrl(r.finalUrl, hosts)) { fail(new Error('unexpected redirect')); return; }
          if (r.status === 404) { settle(); resolve(null); return; }
          if (r.status < 200 || r.status >= 300) { fail(new Error(`HTTP ${r.status}`)); return; }
          const buf = r.response;
          const bytes = buf && typeof buf.byteLength === 'number' ? buf.byteLength : -1;
          if (bytes < 0) { fail(new Error('bad response')); return; }
          if (bytes > MAX_API_BYTES) { fail(new Error('response too large')); return; }
          let json;
          try { json = JSON.parse(decoder.decode(buf)); } catch { fail(new Error('bad JSON')); return; }
          if (!isPlainObj(json)) { fail(new Error('bad JSON')); return; }
          settle();
          resolve(json);
        },
        onerror: () => fail(new Error('network error')),
        ontimeout: () => fail(new Error('timeout')),
        onabort: () => fail(abortError()),
      });
    });
    return {
      promise,
      abort: () => {
        if (settled) return;
        settle();
        try { if (handle) handle.abort(); } catch { }
        rejectFn(abortError());
      },
    };
  }

  const HLS_ORDER = ['livehls', 'liveondemandhls', 'liveplaybackhls', 'hls'];
  function collectHls(root) {
    const out = [];
    const stack = [[root, 0]];
    let nodes = 0;
    const push = (c) => { if (out.length < MAX_URL_CANDIDATES) out.push(c); };
    while (stack.length && nodes < MAX_JSON_NODES && out.length < MAX_URL_CANDIDATES) {
      const [node, depth] = stack.pop();
      nodes += 1;
      if (!node || typeof node !== 'object' || depth > 12) continue;
      if (Array.isArray(node)) {
        for (const n of node) { if (stack.length + nodes >= MAX_JSON_NODES) break; stack.push([n, depth + 1]); }
        continue;
      }
      if (typeof node.url === 'string' && typeof node.type === 'string') push({ type: node.type, url: node.url });
      for (const k of Object.keys(node)) {
        if (out.length >= MAX_URL_CANDIDATES || stack.length + nodes >= MAX_JSON_NODES) break;
        const v = node[k];
        if (typeof v === 'string') { if (/m3u8/i.test(v) && /^https:\/\//i.test(v)) push({ type: k, url: v }); }
        else if (v && typeof v === 'object') stack.push([v, depth + 1]);
      }
    }
    return out;
  }
  function rankHls(c) {
    const t = c.type.replace(/[_\-\s]/g, '').toLowerCase();
    const i = HLS_ORDER.indexOf(t);
    return i >= 0 ? i : 10;
  }
  function findKeyBfs(root, test) {
    const q = [root];
    let head = 0;
    while (head < q.length && head < MAX_JSON_NODES) {
      const cur = q[head++];
      if (!cur || typeof cur !== 'object') continue;
      for (const k of Object.keys(cur)) {
        const v = cur[k];
        const r = test(k, v);
        if (r !== undefined) return r;
        if (v && typeof v === 'object' && q.length < MAX_JSON_NODES) q.push(v);
      }
    }
    return undefined;
  }
  function parseVk(json) {
    const cands = collectHls(json)
      .filter((c) => !/dash|cmaf/i.test(c.type) && /m3u8/i.test(c.url) && isAllowedUrl(c.url, SERVICES.vk.cdnHosts))
      .sort((a, b) => rankHls(a) - rankHls(b));
    let online = findKeyBfs(json, (k, v) => (k === 'isOnline' && typeof v === 'boolean' ? v : undefined));
    if (online === undefined) {
      online = findKeyBfs(json, (k, v) => (k === 'status' && typeof v === 'string' && /^(online|offline|ended)$/i.test(v)
        ? /online/i.test(v) : undefined));
    }
    const title = findKeyBfs(json, (k, v) => (k === 'title' && typeof v === 'string' && v ? v.slice(0, 300) : undefined));
    const url = cands[0] ? cands[0].url : null;
    return { online: online === undefined ? Boolean(url) : online, url, title: title || '' };
  }

  function fetchVk(vk, track) {
    const ch = encodeURIComponent(vk);
    const base = 'https://api.live.vkvideo.ru';
    const opts = { hosts: ['api.live.vkvideo.ru'], headers: { 'X-App': 'streams_web', Referer: `https://live.vkvideo.ru/${vk}` } };
    const reqs = [
      `/v1/channel/${ch}/stream/slot/default`,
      `/v1/blog/${ch}/public_video_stream?from=layer`,
      `/v8/channel/${ch}/stream/slot/default`,
    ].map((ep) => ({ ep, r: track(apiRequest(base + ep, opts)) }));
    return new Promise((resolve, reject) => {
      let left = reqs.length, done = false, errors = 0, lastErr = null;
      const results = [];
      const finish = () => {
        if (done || left > 0) return;
        done = true;
        if (errors === reqs.length) { reject(lastErr || new Error('API')); return; }
        const on = results.find((r) => r.online);
        const any = on || results[0] || {};
        resolve({ online: Boolean(on), url: null, title: any.title || '' });
      };
      reqs.forEach(({ ep, r }) => {
        r.promise.then((json) => {
          if (done || !json) return;
          const s = parseVk(json);
          LOG('vk', ep, s.online, s.url || '');
          if (s.online && s.url) {
            done = true;
            reqs.forEach((x) => { if (x.r !== r) x.r.abort(); });
            resolve(s);
            return;
          }
          results.push(s);
        }).catch((e) => {
          if (done) return;
          errors += 1; lastErr = e;
          if (e.name !== 'AbortError') LOG('vk api error', ep, e.message);
        }).finally(() => { left -= 1; finish(); });
      });
    });
  }

  const UUID_RE = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;
  const wtvIds = new Map();
  async function fetchWtv(nick, track, cancelled) {
    const q = `?user_lang=${RU ? 'ru' : 'en'}&platform=web`;
    const headers = { Referer: 'https://w.tv/' };
    const check = () => { if (cancelled()) throw abortError(); };
    check();
    const cached = wtvIds.get(nick);
    let id = cached && Date.now() - cached.t < WTV_ID_TTL_MS ? cached.id : null;
    if (!id) {
      const j = await track(apiRequest(`https://profiles-service.w.tv/api/v1/profiles/by-nickname/${encodeURIComponent(nick)}${q}`,
        { hosts: ['profiles-service.w.tv'], headers })).promise;
      check();
      const uid = j && isPlainObj(j.profile) ? j.profile.userId : null;
      if (typeof uid !== 'string' || !UUID_RE.test(uid)) return { online: false, url: null, title: '' };
      id = uid.toLowerCase();
      const now = Date.now();
      for (const [k, v] of wtvIds) if (now - v.t >= WTV_ID_TTL_MS) wtvIds.delete(k);
      while (wtvIds.size >= 32) wtvIds.delete(wtvIds.keys().next().value);
      wtvIds.set(nick, { id, t: now });
    }
    check();
    const j = await track(apiRequest(`https://streams-search-service.w.tv/api/v1/channels/${id}${q}`,
      { hosts: ['streams-search-service.w.tv'], headers })).promise;
    check();
    const ch = j && isPlainObj(j.channel) ? j.channel : null;
    const ls = ch && isPlainObj(ch.liveStream) ? ch.liveStream : null;
    const live = Boolean(ch && ch.live === true && ls && ls.state !== 'finished');
    const url = live && typeof ls.playbackUrl === 'string' && isAllowedUrl(ls.playbackUrl, SERVICES.wtv.cdnHosts)
      ? ls.playbackUrl : null;
    const title = ls && typeof ls.title === 'string' ? ls.title.slice(0, 300) : '';
    LOG('wtv', nick, live, url || '');
    return { online: Boolean(url), url, title };
  }

  async function fetchKick(slug, track, cancelled) {
    const check = () => { if (cancelled()) throw abortError(); };
    const base = `https://kick.com/api/v2/channels/${encodeURIComponent(slug)}`;
    const opts = { hosts: ['kick.com'], headers: { Accept: 'application/json', 'X-App-Platform': 'web', Referer: `https://kick.com/${slug}` } };
    check();
    const j = await track(apiRequest(`${base}/info`, opts)).promise;
    check();
    const ls = j && isPlainObj(j.livestream) ? j.livestream : null;
    const live = Boolean(ls && ls.is_live === true);
    const title = ls && typeof ls.session_title === 'string' ? ls.session_title.slice(0, 300) : '';
    let url = live && typeof j.playback_url === 'string' && isAllowedUrl(j.playback_url, SERVICES.kick.cdnHosts) ? j.playback_url : null;
    if (live && !url) {
      const p = await track(apiRequest(`${base}/playback-url`, opts)).promise;
      check();
      const u = p && typeof p.data === 'string' ? p.data : null;
      url = u && isAllowedUrl(u, SERVICES.kick.cdnHosts) ? u : null;
    }
    LOG('kick', slug, live, url || '');
    return { online: Boolean(url), url, title };
  }

  const FETCHERS = { vk: fetchVk, wtv: fetchWtv, kick: fetchKick };

  const transportByHost = new Map();
  const GM_MAX_PARALLEL = 2;
  const gmQueue = [];
  let gmActive = 0;
  function gmAcquire(start) {
    if (gmActive < GM_MAX_PARALLEL) { gmActive += 1; start(); return null; }
    const item = { start, cancelled: false };
    gmQueue.push(item);
    return item;
  }
  function gmRelease() {
    gmActive = Math.max(0, gmActive - 1);
    setTimeout(gmDrain, 0);
  }
  function gmDrain() {
    while (gmActive < GM_MAX_PARALLEL && gmQueue.length) {
      const it = gmQueue.shift();
      if (it.cancelled) continue;
      gmActive += 1;
      try { it.start(); } catch (e) { LOG('gm start error', e && e.message); gmActive = Math.max(0, gmActive - 1); }
    }
  }
  let inflightBytes = 0;

  class SafeLoader {
    constructor(config) {
      this.hosts = (config && Array.isArray(config.tvkHosts)) ? config.tvkHosts : [];
      this.token = 0;
      this.timer = null;
      this.gmReq = null;
      this.gmWait = null;
      this.gmSlot = false;
      this.ac = null;
      this.context = null;
      this.callbacks = null;
      this.counted = 0;
      this.stats = {
        aborted: false, loaded: 0, retry: 0, total: 0, chunkCount: 0, bwEstimate: 0,
        loading: { start: 0, first: 0, end: 0 },
        parsing: { start: 0, end: 0 },
        buffering: { start: 0, first: 0, end: 0 },
      };
    }

    destroy() { this.abortInternal(); this.callbacks = null; }

    abortInternal() {
      this.token += 1;
      clearTimeout(this.timer);
      inflightBytes -= this.counted;
      this.counted = 0;
      if (this.gmReq) { try { this.gmReq.abort(); } catch { } this.gmReq = null; }
      if (this.gmWait) { this.gmWait.cancelled = true; this.gmWait = null; }
      if (this.gmSlot) { this.gmSlot = false; gmRelease(); }
      if (this.ac) { try { this.ac.abort(); } catch { } this.ac = null; }
    }

    abort() {
      this.abortInternal();
      this.stats.aborted = true;
      const cb = this.callbacks;
      if (cb && cb.onAbort) cb.onAbort(this.stats, this.context, null);
    }

    fail(token, code, text) {
      if (token !== this.token) return;
      this.abortInternal();
      if (this.callbacks) this.callbacks.onError({ code, text }, this.context, null, this.stats);
    }

    succeed(token, url, bytes, status) {
      if (token !== this.token) return;
      const stats = this.stats;
      const now = performance.now();
      if (!stats.loading.first) stats.loading.first = now;
      stats.loading.end = now;
      stats.loaded = stats.total = bytes.byteLength;
      const type = this.context.responseType;
      let data;
      if (type === 'arraybuffer') {
        const whole = bytes.byteOffset === 0 && bytes.byteLength === bytes.buffer.byteLength;
        data = whole ? bytes.buffer : bytes.slice().buffer;
      } else if (type === 'json') {
        try { data = JSON.parse(decoder.decode(bytes)); } catch { this.fail(token, 0, 'bad JSON'); return; }
        if (!isPlainObj(data)) { this.fail(token, 0, 'bad JSON'); return; }
      } else {
        data = decoder.decode(bytes);
      }
      this.abortInternal();
      if (this.callbacks) this.callbacks.onSuccess({ url, data, code: status }, stats, this.context, null);
    }

    hold(token, bytes) {
      if (token !== this.token) return false;
      const delta = bytes - this.counted;
      if (delta > 0 && inflightBytes + delta > MAX_INFLIGHT_BYTES) { this.fail(token, 0, 'memory budget exceeded'); return false; }
      inflightBytes += delta;
      this.counted = bytes;
      return true;
    }

    progress(token, loaded, held = loaded) {
      if (token !== this.token) return false;
      const s = this.stats;
      if (!s.loading.first) s.loading.first = performance.now();
      s.loaded = loaded;
      return this.hold(token, held);
    }

    resetStats() {
      const s = this.stats;
      s.aborted = false; s.loaded = 0; s.retry = 0; s.total = 0; s.chunkCount = 0; s.bwEstimate = 0;
      s.loading.start = performance.now(); s.loading.first = 0; s.loading.end = 0;
      s.parsing.start = 0; s.parsing.end = 0;
      s.buffering.start = 0; s.buffering.first = 0; s.buffering.end = 0;
    }

    load(context, config, callbacks) {
      this.abortInternal();
      const token = this.token;
      this.context = context;
      this.callbacks = callbacks;
      this.resetStats();
      const limit = context.responseType === 'arraybuffer' ? MAX_SEGMENT_BYTES : MAX_PLAYLIST_BYTES;

      if (!isAllowedUrl(context.url, this.hosts)) {
        setTimeout(() => this.fail(token, 0, 'URL not allowed'), 0);
        return;
      }
      const pol = config && config.loadPolicy;
      const timeout = (pol && pol.maxLoadTimeMs) || (config && config.timeout) || 20000;
      this.timer = setTimeout(() => {
        if (token !== this.token) return;
        this.abortInternal();
        if (this.callbacks && this.callbacks.onTimeout) this.callbacks.onTimeout(this.stats, context, null);
      }, timeout);

      const host = new URL(context.url).hostname;
      const mode = transportByHost.get(host);
      if (mode === 'gm') this.loadGM(token, context, limit);
      else this.loadDirect(token, context, limit, host, mode !== 'direct');
    }

    async loadDirect(token, context, limit, host, mayFallback) {
      const ac = new AbortController();
      this.ac = ac;
      const headers = {};
      if (context.rangeEnd) headers.Range = `bytes=${context.rangeStart}-${context.rangeEnd - 1}`;
      let r;
      try {
        r = await fetch(context.url, { mode: 'cors', credentials: 'omit', redirect: 'error', cache: 'no-store', signal: ac.signal, headers });
      } catch (e) {
        if (token !== this.token || (e && e.name === 'AbortError')) return;
        if (mayFallback) {
          transportByHost.set(host, 'gm');
          LOG('transport gm:', host);
          this.loadGM(token, context, limit);
        } else {
          this.fail(token, 0, 'network error');
        }
        return;
      }
      if (token !== this.token) return;
      transportByHost.set(host, 'direct');
      if (!r.ok) { this.fail(token, r.status, `HTTP ${r.status}`); return; }
      const declared = Number(r.headers.get('content-length'));
      const hint = Number.isFinite(declared) && declared > 0 ? Math.min(declared, limit) : 64 * 1024;
      const cancel = (reader) => { reader.cancel().catch(() => {}); };
      try {
        const reader = r.body.getReader();
        if (!this.hold(token, hint)) { cancel(reader); return; }
        let buf = new Uint8Array(hint);
        let total = 0;
        for (;;) {
          const { done, value } = await reader.read();
          if (token !== this.token) { cancel(reader); return; }
          if (done) break;
          const need = total + value.byteLength;
          if (need > limit) { cancel(reader); this.fail(token, 0, 'response too large'); return; }
          if (need > buf.byteLength) {
            const cap = Math.min(limit, Math.max(need, buf.byteLength * 2));
            if (!this.hold(token, buf.byteLength + cap)) { cancel(reader); return; }
            const next = new Uint8Array(cap);
            next.set(buf.subarray(0, total));
            buf = next;
            if (!this.hold(token, cap)) { cancel(reader); return; }
          }
          buf.set(value, total);
          total = need;
          if (!this.progress(token, total, buf.byteLength)) { cancel(reader); return; }
        }
        if (total !== buf.byteLength) {
          if (!this.hold(token, buf.byteLength + total)) return;
          buf = buf.slice(0, total);
          if (!this.hold(token, total)) return;
        }
        this.succeed(token, context.url, buf, r.status);
      } catch (e) {
        if (token !== this.token || (e && e.name === 'AbortError')) return;
        this.fail(token, 0, 'read error');
      }
    }

    loadGM(token, context, limit) {
      this.gmWait = gmAcquire(() => {
        this.gmWait = null;
        if (token !== this.token) { gmRelease(); return; }
        this.gmSlot = true;
        try {
          this.startGM(token, context, limit);
        } catch (e) {
          this.fail(token, 0, 'GM start error');
        }
      });
    }

    startGM(token, context, limit) {
      const headers = {};
      if (context.rangeEnd) headers.Range = `bytes=${context.rangeStart}-${context.rangeEnd - 1}`;
      this.gmReq = GM_xmlhttpRequest({
        method: 'GET', url: context.url, headers,
        anonymous: true,
        redirect: 'error',
        responseType: 'arraybuffer',
        onprogress: (e) => {
          if (!e) return;
          if (e.loaded > limit || (e.total && e.total > limit)) { this.fail(token, 0, 'response too large'); return; }
          this.progress(token, e.loaded || 0);
        },
        onload: (r) => {
          if (token !== this.token) return;
          this.gmReq = null;
          const finalUrl = r.finalUrl || context.url;
          if (!isAllowedUrl(finalUrl, this.hosts)) { this.fail(token, 0, 'redirect not allowed'); return; }
          if (r.status < 200 || r.status >= 300) { this.fail(token, r.status, r.statusText || `HTTP ${r.status}`); return; }
          const buf = r.response;
          if (!buf || typeof buf.byteLength !== 'number') { this.fail(token, 0, 'bad response'); return; }
          if (buf.byteLength > limit) { this.fail(token, 0, 'response too large'); return; }
          if (!this.hold(token, buf.byteLength)) return;
          this.succeed(token, finalUrl, new Uint8Array(buf), r.status);
        },
        onerror: () => this.fail(token, 0, 'GM network error'),
      });
    }
  }

  const CSS = `
    :host { all: initial; }
    .wrap { position:absolute; inset:0; background:#000; display:flex; font:13px/1.3 system-ui,sans-serif; color:#fff; }
    .wrap.hidden { display:none; }
    video, iframe { width:100%; height:100%; border:0; display:block; background:#000; }
    video { object-fit:contain; outline:none; }
    .wrap.embed video, .wrap.hls iframe { display:none; }
    .wrap.embed .ctrl { display:none; }
    .top { position:absolute; top:0; right:0; display:flex; gap:6px; align-items:flex-start; padding:6px 8px;
      opacity:0; transition:opacity .2s; }
    .top .title { padding-top:3px; }
    .top .right { display:flex; flex-direction:column; align-items:flex-end; gap:5px; margin-left:auto; }
    .top .row { display:flex; gap:6px; align-items:center; }
    .top .svcs { display:flex; gap:4px; }
    .top .svcs:empty { display:none; }
    .dbgtag { font-size:10px; font-weight:700; color:#ffcc00; border:1px solid #ffcc0088; border-radius:3px; padding:1px 4px; }
    .wrap.hls .top { left:0; background:linear-gradient(#000c,#0000); }
    .wrap:hover .top, .top:focus-within { opacity:1; }
    .wrap.embed .top { opacity:0; }
    .wrap.embed.peek .top, .wrap.embed .top:hover, .wrap.embed .top:focus-within { opacity:1; }
    .title { flex:1; overflow:hidden; white-space:nowrap; text-overflow:ellipsis; opacity:.85; }
    .wrap.embed .title { display:none; }
    input, select, button { font:inherit; color:#fff; background:#1f1f23d9; border:1px solid #fff3; border-radius:4px; padding:2px 6px; }
    input { width:110px; }
    button { cursor:pointer; min-width:26px; }
    button:hover { background:#3a3a3dd9; }

    .badge { display:inline-block; padding:2px 7px; border-radius:4px; font-weight:700; white-space:nowrap; cursor:pointer; outline-offset:2px;
      border:1px solid transparent; }
    .badge.vk { background:#e91916; color:#fff; }
    .badge.wtv { background:linear-gradient(#ffffff,#d9d9de); color:#26262c; border-color:#a9a9b2; }
    .badge.kick { background:#53fc18; color:#0b0e0f; border-color:#3cc70f; }
    .badge.off { opacity:.55; filter:grayscale(.5); }
    .top .badge { padding:1px 6px; font-size:12px; }
    .top .badge.cur { box-shadow:0 0 0 2px #fff; }

    .ctrl { position:absolute; left:0; right:0; bottom:0; display:flex; gap:8px; align-items:center; padding:8px 10px;
      background:linear-gradient(#0000,#000c); opacity:0; transition:opacity .2s; }
    .wrap:hover .ctrl, .ctrl:focus-within, .wrap.paused .ctrl { opacity:1; }
    .ctrl button { background:transparent; border:0; font-size:16px; padding:2px 4px; }
    .ctrl input[type=range] { width:90px; padding:0; accent-color:#fff; background:transparent; border:0; }
    .ctrl .sp { flex:1; }
    .livebtn { font-size:12px !important; font-weight:600; }
    .livebtn::before { content:'●'; color:#888; margin-right:4px; }
    .livebtn.at::before { color:#e91916; }
    .msg { position:absolute; left:50%; top:50%; transform:translate(-50%,-50%); background:#000a; padding:6px 10px; border-radius:6px; pointer-events:none; }
    .msg:empty { display:none; }

    .pills { position:absolute; top:8px; right:8px; display:flex; flex-direction:column; gap:6px; align-items:flex-end; z-index:2;
      opacity:0; visibility:hidden; transition:opacity .25s, visibility 0s linear .25s; }

    .pills.shown, .pills:hover, .pills:focus-within { opacity:1; visibility:visible; transition:opacity .15s, visibility 0s; }
    .pills.hidden { display:none; }
    .pill { display:flex; gap:6px; align-items:center; padding:4px 6px; background:#18181bd9; border:1px solid #fff3;
      border-radius:6px; font:12px/1.3 system-ui,sans-serif; color:#fff; }
    .pill .info { display:flex; flex-direction:column; align-items:flex-end; gap:3px; }
    .pill .status { font-size:11px; font-weight:700; color:#adadb8; letter-spacing:.02em; }
    .pill .status.live { color:#ff3b30; cursor:pointer; }
    .badge:focus-visible, .pill .status:focus-visible { outline:2px solid #fff; }
    .pill:has(.status.live) { border-color:#ff3b3088; }
    .pill .status.live::before { content:'● '; }
    .pill .more { display:none; gap:6px; align-items:center; }
    .pill.open .more { display:flex; }
  `;

  const ui = { host: null, wrap: null, video: null, frame: null, msg: null, pills: null, els: {}, pillEls: {} };

  function h(tag, attrs = {}, ...kids) {
    const el = document.createElement(tag);
    for (const [k, v] of Object.entries(attrs)) {
      if (k.startsWith('on')) el.addEventListener(k.slice(2), v);
      else if (k === 'class') el.className = v;
      else el.setAttribute(k, v);
    }
    kids.forEach((k) => el.append(k));
    return el;
  }

  function asButton(el) {
    el.setAttribute('role', 'button');
    el.setAttribute('tabindex', '0');
    el.addEventListener('keydown', (e) => {
      if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); el.click(); }
    });
    return el;
  }

  function buildUi() {
    if (ui.host) return;
    const host = h('div', { id: 'tvk-host' });
    host.style.cssText = 'position:absolute;inset:0;z-index:2000;pointer-events:none;';
    const root = host.attachShadow({ mode: 'closed' });
    root.append(h('style', {}, CSS));
    const els = {};

    const video = h('video', { playsinline: '' });
    video.volume = DEFAULT_VOLUME.wtv;
    els.play = h('button', { title: T.play, onclick: () => (video.paused ? video.play().catch(() => {}) : video.pause()) }, '⏸');
    els.mute = h('button', { title: T.mute, onclick: () => { video.muted = !video.muted; } }, '🔊');
    els.vol = h('input', { type: 'range', min: '0', max: '1', step: '0.05' });
    els.vol.value = String(video.volume);
    els.vol.addEventListener('input', () => {
      const v = clampNum(els.vol.value, 0, 1, 0.5);
      video.volume = v;
      video.muted = v === 0;

      if (audio.svc && v > 0) store.setVolumeFor(audio.svc, v);
    });
    els.live = h('button', { class: 'livebtn', title: T.toLive, onclick: jumpToLive }, 'LIVE');
    els.quality = h('select', { title: 'Quality', onchange: () => setQuality(Number(els.quality.value)) });
    els.full = h('button', { title: T.full, onclick: toggleFullscreen }, '⛶');
    const ctrl = h('div', { class: 'ctrl' }, els.play, els.mute, els.vol, els.live, h('span', { class: 'sp' }), els.quality, els.full);
    const syncCtrl = () => {
      els.play.textContent = video.paused ? '▶' : '⏸';
      els.mute.textContent = video.muted || video.volume === 0 ? '🔇' : '🔊';
      els.vol.value = String(video.muted ? 0 : video.volume);
      if (ui.wrap) ui.wrap.classList.toggle('paused', video.paused);
    };
    video.addEventListener('play', syncCtrl);
    video.addEventListener('pause', syncCtrl);
    video.addEventListener('volumechange', syncCtrl);
    video.addEventListener('waiting', () => setMsg(T.loading));
    video.addEventListener('playing', () => setMsg(audio.forcedMute ? T.clickUnmute : ''));
    video.addEventListener('timeupdate', () => {
      const edge = hls && hls.liveSyncPosition;
      els.live.classList.toggle('at', Boolean(edge) && video.currentTime >= edge - 6);
    });
    video.addEventListener('click', () => (video.paused ? video.play().catch(() => {}) : video.pause()));
    video.addEventListener('dblclick', (e) => { e.preventDefault(); toggleFullscreen(); });

    const frame = h('iframe', {
      allow: 'autoplay; fullscreen; picture-in-picture; encrypted-media',
      allowfullscreen: '', title: 'VK Video Live', referrerpolicy: 'strict-origin-when-cross-origin',
      scrolling: 'no',
    });
    frame.addEventListener('mouseenter', peekTop);

    els.svcBtns = h('span', { class: 'svcs' });
    els.title = h('span', { class: 'title' });
    els.input = h('input', { type: 'text', placeholder: T.channel, title: `${T.channel} (Enter)`, maxlength: '64' });
    els.input.addEventListener('keydown', (e) => { if (e.key === 'Enter') applyInput(state.current, els.input.value); });
    els.mode = h('button', { title: T.mode, onclick: toggleVkMode }, 'HLS');
    els.reload = h('button', { title: T.reload, onclick: reload }, '⟳');
    els.hide = h('button', { title: T.hide, onclick: () => dismiss() }, T.hide);
    els.dbg = h('span', { class: 'dbgtag', title: 'Alt+Shift+D' }, 'DEBUG');

    const right = h('div', { class: 'right' },
      h('div', { class: 'row' }, els.dbg, els.input, els.mode, els.reload, els.hide),
      els.svcBtns);
    const top = h('div', { class: 'top' }, els.title, right);

    const msg = h('div', { class: 'msg' });
    const wrap = h('div', { class: 'wrap hidden' }, video, frame, ctrl, top, msg);
    wrap.style.pointerEvents = 'auto';

    const pills = h('div', { class: 'pills hidden' });
    pills.style.pointerEvents = 'auto';
    const pillEls = {};
    for (const svc of ORDER) {
      const S = SERVICES[svc];
      const badge = asButton(h('span', { class: `badge ${S.cls}`, title: S.name }));
      const status = asButton(h('span', { class: 'status' }));
      const input = h('input', { type: 'text', placeholder: `${S.name} ${T.channel}`, maxlength: '64' });
      input.addEventListener('keydown', (e) => { if (e.key === 'Enter') applyInput(svc, input.value); });
      const more = h('span', { class: 'more' }, input, h('button', { onclick: () => applyInput(svc, input.value) }, T.show));
      const pill = h('div', { class: 'pill' }, more, h('span', { class: 'info' }, badge, status));
      badge.addEventListener('click', () => {
        if (!debug.on) { if (state.svc[svc].online) { state.chosen = svc; state.dismissed = false; render(); } return; }
        pill.classList.toggle('open');
        if (pill.classList.contains('open')) { input.value = state.chans[svc] || ''; input.focus(); }
      });
      status.addEventListener('click', () => {
        if (state.svc[svc].online) { state.chosen = svc; state.dismissed = false; render(); }
      });
      pills.append(pill);
      pillEls[svc] = { pill, badge, status, input };
    }

    root.append(wrap, pills);

    for (const ev of ['keydown', 'keyup', 'keypress']) host.addEventListener(ev, (e) => e.stopPropagation());
    for (const ev of ['click', 'dblclick', 'mousedown', 'pointerdown', 'wheel']) {
      wrap.addEventListener(ev, (e) => e.stopPropagation());
      pills.addEventListener(ev, (e) => e.stopPropagation());
    }

    Object.assign(ui, { host, wrap, video, frame, msg, pills, els, pillEls });
    syncCtrl();
  }

  function toggleFullscreen() {
    if (document.fullscreenElement) document.exitFullscreen().catch(() => {});
    else ui.host.requestFullscreen().catch(() => {});
  }

  function jumpToLive() {
    if (hls && hls.liveSyncPosition) ui.video.currentTime = hls.liveSyncPosition;
    ui.video.play().catch(() => {});
  }

  const PLAYER_SEL = [
    '.video-player__container',
    '[data-a-target="video-player"]',
    '.video-player',
    '.persistent-player',
    '.channel-root__player',
    '[data-a-target="home-offline-hero"]',
    '.home-offline-hero',
  ];
  let fallbackBox = null;
  let container = null;

  function findContainer() {
    for (const sel of PLAYER_SEL) {
      for (const el of document.querySelectorAll(sel)) {
        if (el === fallbackBox) continue;
        const r = el.getBoundingClientRect();
        if (r.width >= 320 && r.height >= 180) return el;
      }
    }
    return null;
  }

  function ensureFallbackBox() {
    if (fallbackBox && fallbackBox.isConnected) return fallbackBox;
    const parent = document.querySelector('.channel-root') || document.querySelector('main .simplebar-scroll-content')
      || document.querySelector('main');
    if (!parent) return null;
    fallbackBox = h('div', { id: 'tvk-fallback' });
    fallbackBox.style.cssText = 'position:relative;width:100%;aspect-ratio:16/9;max-height:80vh;background:#000;';
    parent.prepend(fallbackBox);
    return fallbackBox;
  }

  function removeFallbackBox() {
    if (fallbackBox) { fallbackBox.remove(); fallbackBox = null; }
  }

  const PILLS_HIDE_DELAY_MS = 3000;
  let hoverAc = null;
  let hoverTimer = null;
  function showPills() {
    clearTimeout(hoverTimer);
    if (ui.pills) ui.pills.classList.add('shown');
  }
  function hidePillsLater() {
    clearTimeout(hoverTimer);
    hoverTimer = setTimeout(() => {
      if (!ui.pills) return;
      const typing = ORDER.some((s) => ui.pillEls[s] && ui.pillEls[s].pill.classList.contains('open'));
      if (typing) { hidePillsLater(); return; }
      ui.pills.classList.remove('shown');
    }, PILLS_HIDE_DELAY_MS);
  }
  function bindHover(el) {
    if (hoverAc) hoverAc.abort();
    hoverAc = new AbortController();
    const opt = { signal: hoverAc.signal, passive: true };

    const onMouse = (fn) => (e) => { if (e.pointerType === 'mouse') fn(); };
    el.addEventListener('pointerenter', onMouse(showPills), opt);
    el.addEventListener('pointermove', onMouse(showPills), opt);
    el.addEventListener('pointerleave', onMouse(hidePillsLater), opt);

    el.addEventListener('focusin', showPills, opt);
    el.addEventListener('focusout', hidePillsLater, opt);

    el.addEventListener('pointerdown', (e) => { if (e.pointerType !== 'mouse') { showPills(); hidePillsLater(); } }, opt);
  }

  function attach(needBox) {
    buildUi();
    const placed = ui.host.isConnected && ui.host.parentElement === container
      && container && container.isConnected && container !== fallbackBox;
    if (placed) return true;
    let c = findContainer();
    if (c) removeFallbackBox();
    else if (needBox) c = ensureFallbackBox();
    if (!c) return false;
    if (container !== c) bindHover(c);
    container = c;
    if (ui.host.parentElement !== c) {
      if (getComputedStyle(c).position === 'static') c.style.position = 'relative';
      c.append(ui.host);
      if (state.active && state.playingKey && state.playingKey.includes(':hls:')) ui.video.play().catch(() => {});
    }
    return true;
  }

  function detach() {
    if (ui.host) ui.host.remove();
    removeFallbackBox();
    container = null;
    if (hoverAc) { hoverAc.abort(); hoverAc = null; }
    clearTimeout(hoverTimer);
    if (ui.pills) ui.pills.classList.remove('shown');
  }

  const twitchSaved = new Map();
  function twitchVideos() {
    const scope = container && container !== fallbackBox ? container : null;
    const list = scope ? [...scope.querySelectorAll('video')] : [];
    for (const v of document.querySelectorAll('.persistent-player video, [data-a-target="video-player"] video')) {
      if (!list.includes(v)) list.push(v);
    }
    return list.filter((v) => v !== ui.video);
  }
  function silenceTwitch() {
    for (const [v] of twitchSaved) if (!v.isConnected) twitchSaved.delete(v);
    for (const v of twitchVideos()) {
      if (!twitchSaved.has(v)) twitchSaved.set(v, { muted: v.muted, playing: !v.paused });
      if (!v.muted) v.muted = true;
      if (!v.paused) v.pause();
    }
  }
  function restoreTwitch() {
    for (const [v, s] of twitchSaved) {
      if (!v.isConnected) continue;
      v.muted = s.muted;
      if (s.playing) v.play().catch(() => {});
    }
    twitchSaved.clear();
  }

  const audio = { svc: null, forcedMute: false };
  function applyVolume(svc) {
    audio.svc = svc;
    audio.forcedMute = false;
    ui.video.volume = store.volumeFor(svc);
    ui.video.muted = false;
  }

  for (const ev of ['pointerdown', 'keydown']) {
    window.addEventListener(ev, (e) => {
      if (!e.isTrusted || !audio.forcedMute || !ui.video) return;
      audio.forcedMute = false;
      ui.video.volume = store.volumeFor(audio.svc);
      ui.video.muted = false;
      setMsg('');
    }, true);
  }

  let hls = null;
  let netErrors = 0;
  let mediaErrors = 0;
  let playGen = 0;

  function stopPlayback() {
    playGen += 1;
    audio.forcedMute = false;
    setMsg('');
    if (hls) { hls.destroy(); hls = null; }
    if (ui.video) { ui.video.removeAttribute('src'); ui.video.load(); }
    if (ui.frame && ui.frame.getAttribute('src')) ui.frame.removeAttribute('src');
    state.playingKey = null;
  }

  const PEEK_MS = 1500;
  let peekTimer = null;
  function peekTop() {
    if (!ui.wrap) return;
    ui.wrap.classList.add('peek');
    clearTimeout(peekTimer);
    peekTimer = setTimeout(() => ui.wrap.classList.remove('peek'), PEEK_MS);
  }

  window.addEventListener('message', (e) => {
    if (e.origin !== 'https://live.vkvideo.ru' || !ui.frame || e.source !== ui.frame.contentWindow) return;
    if (!isPlainObj(e.data) || e.data.tvk !== 'activity') return;
    peekTop();
  });

  function startEmbed(svc, ch) {
    const key = `${svc}:embed:${ch}`;
    if (state.playingKey === key) return;
    stopPlayback();
    state.playingKey = key;
    ui.frame.src = SERVICES[svc].embedUrl(ch);
    peekTop();
  }

  function startHls(svc, url) {
    const S = SERVICES[svc];
    if (!isAllowedUrl(url, S.cdnHosts)) return;
    const key = `${svc}:hls:${url}`;
    if (state.playingKey === key) return;
    stopPlayback();
    state.playingKey = key;
    netErrors = 0;
    mediaErrors = 0;
    const video = ui.video;
    applyVolume(svc);
    if (!(window.Hls && Hls.isSupported())) { setMsg(T.noHls); return; }
    setMsg(T.loading);

    hls = new Hls({
      loader: SafeLoader,
      tvkHosts: S.cdnHosts,
      lowLatencyMode: false,
      liveSyncDurationCount: 2,
      maxBufferLength: 15,
      backBufferLength: 10,
      startFragPrefetch: true,
      startLevel: -1,
      abrEwmaDefaultEstimate: 3_000_000,
    });
    hls.on(Hls.Events.MANIFEST_PARSED, () => {
      fillQuality();
      const q = store.quality();
      if (q >= 0 && q < hls.levels.length) hls.currentLevel = q;
      const gen = playGen;
      video.play().catch((e) => {

        if (gen !== playGen || !e || e.name !== 'NotAllowedError') return;

        video.muted = true;
        audio.forcedMute = true;
        setMsg(T.clickUnmute);
        video.play().catch(() => {});
      });
    });
    hls.on(Hls.Events.LEVEL_SWITCHED, () => fillQuality());
    hls.on(Hls.Events.FRAG_LOADED, () => { netErrors = 0; });
    hls.on(Hls.Events.FRAG_BUFFERED, () => { mediaErrors = 0; });
    hls.on(Hls.Events.ERROR, (_e, d) => {
      if (!d.fatal) return;
      LOG('hls fatal', d.type, d.details);
      if (d.type === Hls.ErrorTypes.MEDIA_ERROR) {
        mediaErrors += 1;
        if (mediaErrors === 1) { hls.recoverMediaError(); return; }
        if (mediaErrors === 2) { hls.swapAudioCodec(); hls.recoverMediaError(); return; }
        setMsg(`${T.streamErr} (${d.details})`);
        return;
      }
      setMsg(T.streamErr);
      netErrors += 1;
      if (netErrors <= 2) { hls.startLoad(); return; }
      transportByHost.clear();
      state.playingKey = null;
      pollService(svc, true, true);
    });
    hls.loadSource(url);
    hls.attachMedia(video);
  }

  function fillQuality() {
    const sel = ui.els.quality;
    if (!hls || !hls.levels || hls.levels.length < 2) { sel.style.display = 'none'; return; }
    sel.style.display = '';
    const cur = hls.autoLevelEnabled ? -1 : hls.currentLevel;
    sel.textContent = '';
    sel.append(h('option', { value: '-1' }, T.auto + (hls.autoLevelEnabled && hls.levels[hls.currentLevel]
      ? ` (${hls.levels[hls.currentLevel].height || '?'}p)` : '')));
    hls.levels.forEach((l, i) => sel.append(h('option', { value: String(i) },
      l.height ? `${l.height}p${l.frameRate > 30 ? Math.round(l.frameRate) : ''}` : `${Math.round((l.bitrate || 0) / 1000)}k`)));
    sel.value = String(cur);
  }

  function setQuality(q) {
    store.setQuality(q);
    if (hls && q >= -1 && q < hls.levels.length) hls.currentLevel = q;
  }

  let msgTimer = null;
  function setMsg(text, ms) {
    if (!ui.msg) return;
    clearTimeout(msgTimer);
    ui.msg.textContent = text;
    if (ms) msgTimer = setTimeout(() => { ui.msg.textContent = ''; }, ms);
  }

  const newSvcState = () => ({ online: false, url: null, title: '', status: '', seq: 0, timer: null, inflight: [] });
  const state = {
    tw: null,
    chans: dict(),
    svc: { vk: newSvcState(), wtv: newSvcState(), kick: newSvcState() },
    current: null,
    chosen: null,
    vkMode: store.vkMode(),

    dismissed: true, active: false, playingKey: null,
    openWhenLive: null,
  };

  const vkMode = () => (debug.on ? state.vkMode : 'embed');

  const playable = (svc) => {
    const s = state.svc[svc];
    if (!state.chans[svc] || !s.online) return false;
    if (svc === 'vk' && vkMode() === 'embed') return true;
    return Boolean(s.url);
  };

  function render() {
    const configured = ORDER.filter((s) => state.chans[s]);
    if (!configured.length) {
      if (state.active) restoreTwitch();
      state.active = false;
      state.current = null;
      stopPlayback();
      detach();
      return;
    }
    const cands = ORDER.filter(playable);

    if (state.openWhenLive && cands.includes(state.openWhenLive)) {
      state.chosen = state.openWhenLive;
      state.openWhenLive = null;
      state.dismissed = false;
    }
    const pick = [state.chosen, ...cands].find((s) => s && cands.includes(s)) || null;

    if (!pick && state.active) state.dismissed = true;
    const show = Boolean(pick) && !state.dismissed;
    if (!attach(show)) return;

    const embed = show && pick === 'vk' && vkMode() === 'embed';
    ui.wrap.classList.toggle('hidden', !show);
    ui.wrap.classList.toggle('embed', embed);
    ui.wrap.classList.toggle('hls', !embed);
    ui.pills.classList.toggle('hidden', show);
    if (show) {
      ui.els.svcBtns.textContent = '';
      for (const s of cands) {
        const b = asButton(h('span', { class: `badge ${SERVICES[s].cls}${s === pick ? ' cur' : ''}`, title: SERVICES[s].name },
          SERVICES[s].name));
        b.addEventListener('click', () => { state.chosen = s; render(); });
        ui.els.svcBtns.append(b);
      }

      ui.els.input.style.display = debug.on ? '' : 'none';
      ui.els.mode.style.display = debug.on && pick === 'vk' ? '' : 'none';
      ui.els.mode.textContent = vkMode() === 'embed' ? 'HLS' : 'Embed';
      ui.els.dbg.style.display = debug.on ? '' : 'none';
      ui.els.title.textContent = state.svc[pick].title || '';
      ui.els.title.title = state.svc[pick].title || '';
      if (!ui.host.matches(':focus-within')) ui.els.input.value = state.chans[pick] || '';
    }

    for (const s of ORDER) {
      const p = ui.pillEls[s];
      const st = state.svc[s];
      p.pill.style.display = state.chans[s] ? '' : 'none';
      p.badge.textContent = `${SERVICES[s].name} · ${state.chans[s] || ''}`;
      p.badge.classList.toggle('off', !st.online);
      p.status.textContent = st.status;
      p.status.classList.toggle('live', st.online);
      p.status.title = st.online ? T.watch : '';
      p.badge.title = st.online ? T.watch : SERVICES[s].name;
    }

    if (show) {
      state.active = true;
      silenceTwitch();
      if (pick !== state.current) stopPlayback();
      state.current = pick;
      if (embed) startEmbed(pick, state.chans[pick]);
      else startHls(pick, state.svc[pick].url);
    } else {
      state.current = null;
      if (state.active) { state.active = false; stopPlayback(); restoreTwitch(); }
    }
  }

  function cancelService(svc) {
    const s = state.svc[svc];
    s.seq += 1;
    clearTimeout(s.timer);
    s.inflight.forEach((r) => r.abort());
    s.inflight = [];
  }

  async function pollService(svc, now = false, urgent = false) {
    const s = state.svc[svc];
    cancelService(svc);
    const ch = state.chans[svc];
    if (!ch) return;

    if (document.hidden && !urgent) { s.deferred = true; return; }
    s.deferred = false;
    const seq = s.seq;
    if (now && !s.online) { s.status = T.checking; render(); }
    const cancelled = () => seq !== s.seq || ch !== state.chans[svc];
    const track = (r) => { if (cancelled()) r.abort(); else s.inflight.push(r); return r; };
    let delay = POLL_MS;
    try {
      const r = await FETCHERS[svc](ch, track, cancelled);
      if (seq !== s.seq || ch !== state.chans[svc]) return;
      s.online = Boolean(r.online);
      s.title = r.title || '';
      s.url = r.url || null;
      s.status = s.online ? T.live : T.offline;
    } catch (e) {
      if (seq !== s.seq || e.name === 'AbortError') return;
      s.status = `${T.error}: ${e.message}`;
      delay = POLL_ERR_MS;
    }
    s.inflight = [];
    render();
    s.timer = setTimeout(() => pollService(svc), delay);
  }

  function pollAll(now = false) { ORDER.forEach((svc) => pollService(svc, now)); }

  function reload() {
    state.dismissed = false;
    stopPlayback();
    pollAll(true);
  }

  function toggleVkMode() {
    state.vkMode = state.vkMode === 'embed' ? 'hls' : 'embed';
    store.setVkMode(state.vkMode);
    stopPlayback();
    render();
  }

  function applyInput(svc, value) {
    const tw = state.tw;
    if (!tw) { alert(T.notChannel); return; }
    if (!svc || !has(SERVICES, svc)) return;
    const raw = String(value || '').trim();
    const ch = norm(raw);
    if (raw && !ch) { setMsg(T.badChannel, 2000); return; }
    const o = overrides.get();
    const cur = has(o, tw) ? o[tw] : dict();
    if (ch) cur[svc] = ch; else delete cur[svc];
    if (Object.keys(cur).length) o[tw] = cur; else delete o[tw];
    overrides.set(o);
    if (ch) { state.chosen = svc; state.openWhenLive = svc; }
    if (ui.pillEls[svc]) ui.pillEls[svc].pill.classList.remove('open');
    onRoute(true);
  }

  function dismiss() {
    state.dismissed = true;
    state.openWhenLive = null;
    render();
  }

  function onRoute(force = false) {
    const tw = currentTwitchChannel();
    const chans = resolveChannels(tw);
    const same = tw === state.tw && ORDER.every((s) => chans[s] === state.chans[s]);
    if (!force && same) return false;
    LOG('route', tw || '-', JSON.stringify(chans));
    const prev = state.chans;
    if (tw !== state.tw) {
      state.chosen = null;
      state.openWhenLive = null;
      state.dismissed = true;
    }
    state.tw = tw;
    state.chans = chans;
    for (const svc of ORDER) {
      if (chans[svc] !== prev[svc]) {
        cancelService(svc);
        state.svc[svc] = newSvcState();
        if (state.current === svc) stopPlayback();
      }
    }
    render();
    for (const svc of ORDER) {
      if (chans[svc]) { if (force || chans[svc] !== prev[svc]) pollService(svc, true); } else cancelService(svc);
    }
    return true;
  }

  setInterval(() => {
    if (onRoute()) return;
    if (!ORDER.some((s) => state.chans[s])) return;
    const misplaced = !ui.host || !ui.host.isConnected || container === fallbackBox;
    if (misplaced) render();
    if (state.active) silenceTwitch();
  }, TICK_MS);

  document.addEventListener('visibilitychange', () => {
    if (document.hidden) {
      ORDER.forEach((s) => { if (state.chans[s]) { cancelService(s); state.svc[s].deferred = true; } });
      return;
    }
    ORDER.forEach((s) => { if (state.chans[s]) pollService(s); });
  });

  const mapToText = (m) => Object.keys(m).map((tw) => `${tw}=${ORDER.filter((s) => m[tw][s]).map((s) => `${s}:${m[tw][s]}`).join(',')}`).join('; ');

  GM_registerMenuCommand(T.menuMap, () => {
    const v = prompt(T.promptMap, mapToText(store.map()));
    if (v === null) return;
    const m = {};
    v.split(/[;\n]+/).forEach((entry) => {
      const i = entry.indexOf('=');
      if (i < 0) return;
      const tw = norm(entry.slice(0, i));
      if (tw) m[tw] = entry.slice(i + 1);
    });
    store.setMap(m);
    onRoute(true);
  });

  function registerDebugMenu() {
    const add = (name, fn) => { try { debug.menuIds.push(GM_registerMenuCommand(name, fn)); } catch { } };
    add(T.menuMode, toggleVkMode);
    add(T.menuDebug, () => {
      const tw = currentTwitchChannel();
      if (!tw) { alert(T.notChannel); return; }
      const cur = resolveChannels(tw);
      const v = prompt(`${T.promptDebug}\n(twitch: ${tw})`, ORDER.filter((s) => cur[s]).map((s) => `${s}:${cur[s]}`).join(','));
      if (v === null) return;
      const o = overrides.get();
      const parsed = cleanSvcMap(v);
      if (Object.keys(parsed).length) o[tw] = parsed; else delete o[tw];
      overrides.set(o);
      onRoute(true);
    });
    add(T.menuReset, () => {
      overrides.set({});
      onRoute(true);
    });
    add(T.menuDebugOff, () => setDebug(false));
  }
  function unregisterDebugMenu() {
    if (typeof GM_unregisterMenuCommand === 'function') {
      for (const id of debug.menuIds) { try { GM_unregisterMenuCommand(id); } catch { } }
    }
    debug.menuIds = [];
  }

  function setDebug(on) {
    if (debug.on === on) return;
    debug.on = on;
    if (on) registerDebugMenu(); else unregisterDebugMenu();
    if (!on) for (const s of ORDER) { const p = ui.pillEls && ui.pillEls[s]; if (p) p.pill.classList.remove('open'); }
    stopPlayback();
    state.current = null;
    state.chosen = null;
    state.openWhenLive = null;
    onRoute(true);
    setMsg(on ? 'DEBUG ON' : 'DEBUG OFF', 1500);
  }

  window.addEventListener('keydown', (e) => {
    if (!e.isTrusted || !DEBUG_HOTKEY(e) || e.repeat) return;
    e.preventDefault();
    e.stopPropagation();
    setDebug(!debug.on);
  }, true);

  if (debug.on) registerDebugMenu();
  overrides.ready.then(() => onRoute(true));
})();
});
