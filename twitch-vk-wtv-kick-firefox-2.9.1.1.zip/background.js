'use strict';

const api = globalThis.browser || globalThis.chrome;

const ALLOWED_HOSTS = [
  'api.live.vkvideo.ru',
  'okcdn.ru',
  'mycdn.me',
  'vkuser.net',
  'profiles-service.w.tv',
  'streams-search-service.w.tv',
  'live-video.net',
  'kick.com',
];
const MAX_BYTES = 70 * 1024 * 1024;
const FORBIDDEN_HEADERS = new Set(['referer', 'origin', 'cookie', 'host', 'connection', 'content-length', 'user-agent']);

const isAllowed = (raw) => {
  let u;
  try { u = new URL(raw); } catch { return false; }
  if (u.protocol !== 'https:' || u.port !== '' || u.username || u.password) return false;
  const host = u.hostname.toLowerCase();
  if (/^[\d.]+$/.test(host) || host.includes(':') || host.startsWith('[')) return false;
  return ALLOWED_HOSTS.some((d) => host === d || host.endsWith(`.${d}`));
};

const toB64 = (bytes) => {
  let s = '';
  const step = 0x8000;
  for (let i = 0; i < bytes.length; i += step) s += String.fromCharCode.apply(null, bytes.subarray(i, i + step));
  return btoa(s);
};

const SESSION_RULES = [
  { id: 1, host: 'api.live.vkvideo.ru', origin: 'https://live.vkvideo.ru' },
  { id: 2, host: 'profiles-service.w.tv', origin: 'https://w.tv' },
  { id: 3, host: 'streams-search-service.w.tv', origin: 'https://w.tv' },
  { id: 4, host: 'kick.com', origin: 'https://kick.com' },
].map((r) => ({
  id: r.id,
  priority: 1,
  action: {
    type: 'modifyHeaders',
    requestHeaders: [
      { header: 'origin', operation: 'set', value: r.origin },
      { header: 'referer', operation: 'set', value: `${r.origin}/` },
    ],
  },
  condition: { requestDomains: [r.host], tabIds: [-1], resourceTypes: ['xmlhttprequest', 'other'] },
}));

const installRules = () => {
  try {
    Promise.resolve(api.declarativeNetRequest.updateSessionRules({
      removeRuleIds: SESSION_RULES.map((r) => r.id),
      addRules: SESSION_RULES,
    })).catch(() => {});
  } catch { }
};
installRules();
api.runtime.onStartup.addListener(installRules);
api.runtime.onInstalled.addListener(installRules);

const fromOurContentScript = (sender) => Boolean(sender && sender.id === api.runtime.id && sender.tab && typeof sender.tab.id === 'number');

api.runtime.onConnect.addListener((port) => {
  if (port.name !== 'tvk-xhr' || !fromOurContentScript(port.sender)) { port.disconnect(); return; }
  const ac = new AbortController();
  let timer = null;
  let closed = false;
  const post = (m) => { if (!closed) { try { port.postMessage(m); } catch { } } };
  port.onDisconnect.addListener(() => { closed = true; ac.abort(); clearTimeout(timer); });

  port.onMessage.addListener(async (m) => {
    if (!m) return;
    if (m.t === 'abort') { ac.abort(); return; }
    if (m.t !== 'req') return;
    if (m.method !== 'GET' || !isAllowed(m.url)) { post({ t: 'error', error: 'request not allowed' }); return; }

    const headers = {};
    for (const [k, v] of Object.entries(m.headers || {})) {
      if (typeof v === 'string' && !FORBIDDEN_HEADERS.has(k.toLowerCase())) headers[k] = v;
    }
    let timedOut = false;
    if (m.timeout > 0) timer = setTimeout(() => { timedOut = true; ac.abort(); post({ t: 'timeout' }); }, m.timeout);

    try {
      const res = await fetch(m.url, {
        method: 'GET',
        headers,
        credentials: m.anonymous ? 'omit' : 'include',
        redirect: m.redirect === 'error' ? 'error' : 'follow',
        cache: 'no-store',
        signal: ac.signal,
      });
      if (!isAllowed(res.url || m.url)) { post({ t: 'error', error: 'redirect not allowed' }); return; }
      const total = Number(res.headers.get('content-length')) || 0;
      const reader = res.body ? res.body.getReader() : null;
      const chunks = [];
      let loaded = 0;
      let lastProgress = 0;
      if (reader) {
        for (;;) {
          const { done, value } = await reader.read();
          if (done) break;
          loaded += value.byteLength;
          if (loaded > MAX_BYTES) { ac.abort(); post({ t: 'error', error: 'response too large' }); return; }
          chunks.push(value);
          const now = Date.now();
          if (now - lastProgress > 100) { lastProgress = now; post({ t: 'progress', loaded, total }); }
        }
      }
      const body = new Uint8Array(loaded);
      let off = 0;
      for (const c of chunks) { body.set(c, off); off += c.byteLength; }
      clearTimeout(timer);
      post({ t: 'progress', loaded, total });
      post({ t: 'load', status: res.status, statusText: res.statusText, finalUrl: res.url || m.url, body: toB64(body) });
    } catch (e) {
      clearTimeout(timer);
      if (timedOut || closed) return;
      post({ t: 'error', error: e && e.name === 'AbortError' ? 'aborted' : 'network error' });
    }
  });
});

const tabKey = (id) => `tab:${id}`;
const session = api.storage.session || null;
const memoryTabs = new Map();

api.runtime.onMessage.addListener((m, sender, send) => {
  if (!m || !fromOurContentScript(sender)) return undefined;
  const key = tabKey(sender.tab.id);
  if (m.t === 'tab-get') {
    if (session) {
      Promise.resolve(session.get(key)).then((r) => send((r && r[key]) || {}), () => send({}));
      return true;
    }
    send(memoryTabs.get(key) || {});
    return undefined;
  }
  if (m.t === 'tab-save') {
    const v = m.v && typeof m.v === 'object' ? m.v : {};
    if (session) Promise.resolve(session.set({ [key]: v })).catch(() => {});
    else memoryTabs.set(key, v);
    send(true);
  }
  return undefined;
});

api.tabs.onRemoved.addListener((tabId) => {
  const key = tabKey(tabId);
  memoryTabs.delete(key);
  if (session) Promise.resolve(session.remove(key)).catch(() => {});
});
